/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SrvRecordSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the record set. The `zone` argument will be appended to this value to create the full record path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/dns/3.6.2/docs/resources/srv_record_set#name SrvRecordSet#name}
    */
    readonly name: string;
    /**
    * The TTL of the record set. Defaults to `3600`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/dns/3.6.2/docs/resources/srv_record_set#ttl SrvRecordSet#ttl}
    */
    readonly ttl?: number;
    /**
    * DNS zone the record set belongs to. It must be an FQDN, that is, include the trailing dot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/dns/3.6.2/docs/resources/srv_record_set#zone SrvRecordSet#zone}
    */
    readonly zone: string;
    /**
    * srv block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/dns/3.6.2/docs/resources/srv_record_set#srv SrvRecordSet#srv}
    */
    readonly srv?: SrvRecordSetSrv[] | cdktn.IResolvable;
}
export interface SrvRecordSetSrv {
    /**
    * The port for the service on the target.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/dns/3.6.2/docs/resources/srv_record_set#port SrvRecordSet#port}
    */
    readonly port: number;
    /**
    * The priority for the record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/dns/3.6.2/docs/resources/srv_record_set#priority SrvRecordSet#priority}
    */
    readonly priority: number;
    /**
    * The FQDN of the target, include the trailing dot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/dns/3.6.2/docs/resources/srv_record_set#target SrvRecordSet#target}
    */
    readonly target: string;
    /**
    * The weight for the record.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/dns/3.6.2/docs/resources/srv_record_set#weight SrvRecordSet#weight}
    */
    readonly weight: number;
}
export declare function srvRecordSetSrvToTerraform(struct?: SrvRecordSetSrv | cdktn.IResolvable): any;
export declare function srvRecordSetSrvToHclTerraform(struct?: SrvRecordSetSrv | cdktn.IResolvable): any;
export declare class SrvRecordSetSrvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SrvRecordSetSrv | cdktn.IResolvable | undefined;
    set internalValue(value: SrvRecordSetSrv | cdktn.IResolvable | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    get weightInput(): number | undefined;
}
export declare class SrvRecordSetSrvList extends cdktn.ComplexList {
    internalValue?: SrvRecordSetSrv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SrvRecordSetSrvOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/dns/3.6.2/docs/resources/srv_record_set dns_srv_record_set}
*/
export declare class SrvRecordSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "dns_srv_record_set";
    /**
    * Generates CDKTN code for importing a SrvRecordSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SrvRecordSet to import
    * @param importFromId The id of the existing SrvRecordSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/dns/3.6.2/docs/resources/srv_record_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SrvRecordSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/dns/3.6.2/docs/resources/srv_record_set dns_srv_record_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SrvRecordSetConfig
    */
    constructor(scope: Construct, id: string, config: SrvRecordSetConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    get zoneInput(): string | undefined;
    private _srv;
    get srv(): SrvRecordSetSrvList;
    putSrv(value: SrvRecordSetSrv[] | cdktn.IResolvable): void;
    resetSrv(): void;
    get srvInput(): cdktn.IResolvable | SrvRecordSetSrv[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
