/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDnsNsRecordSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Host to look up.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/dns/3.6.1/docs/data-sources/ns_record_set#host DataDnsNsRecordSet#host}
    */
    readonly host: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/dns/3.6.1/docs/data-sources/ns_record_set dns_ns_record_set}
*/
export declare class DataDnsNsRecordSet extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "dns_ns_record_set";
    /**
    * Generates CDKTN code for importing a DataDnsNsRecordSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDnsNsRecordSet to import
    * @param importFromId The id of the existing DataDnsNsRecordSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/dns/3.6.1/docs/data-sources/ns_record_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDnsNsRecordSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/dns/3.6.1/docs/data-sources/ns_record_set dns_ns_record_set} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDnsNsRecordSetConfig
    */
    constructor(scope: Construct, id: string, config: DataDnsNsRecordSetConfig);
    private _host?;
    get host(): string;
    set host(value: string);
    get hostInput(): string | undefined;
    get id(): string;
    get nameservers(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
