/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
export * as aRecordSet from './a-record-set/index';
export * as aaaaRecordSet from './aaaa-record-set/index';
export * as cnameRecord from './cname-record/index';
export * as mxRecordSet from './mx-record-set/index';
export * as nsRecordSet from './ns-record-set/index';
export * as ptrRecord from './ptr-record/index';
export * as srvRecordSet from './srv-record-set/index';
export * as txtRecordSet from './txt-record-set/index';
export * as dataDnsARecordSet from './data-dns-a-record-set/index';
export * as dataDnsAaaaRecordSet from './data-dns-aaaa-record-set/index';
export * as dataDnsCnameRecordSet from './data-dns-cname-record-set/index';
export * as dataDnsMxRecordSet from './data-dns-mx-record-set/index';
export * as dataDnsNsRecordSet from './data-dns-ns-record-set/index';
export * as dataDnsPtrRecordSet from './data-dns-ptr-record-set/index';
export * as dataDnsSrvRecordSet from './data-dns-srv-record-set/index';
export * as dataDnsTxtRecordSet from './data-dns-txt-record-set/index';
export * as provider from './provider/index';
