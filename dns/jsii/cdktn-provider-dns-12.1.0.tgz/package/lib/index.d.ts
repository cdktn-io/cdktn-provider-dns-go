/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
export * as aRecordSet from './a-record-set';
export * as aaaaRecordSet from './aaaa-record-set';
export * as cnameRecord from './cname-record';
export * as mxRecordSet from './mx-record-set';
export * as nsRecordSet from './ns-record-set';
export * as ptrRecord from './ptr-record';
export * as srvRecordSet from './srv-record-set';
export * as txtRecordSet from './txt-record-set';
export * as dataDnsARecordSet from './data-dns-a-record-set';
export * as dataDnsAaaaRecordSet from './data-dns-aaaa-record-set';
export * as dataDnsCnameRecordSet from './data-dns-cname-record-set';
export * as dataDnsMxRecordSet from './data-dns-mx-record-set';
export * as dataDnsNsRecordSet from './data-dns-ns-record-set';
export * as dataDnsPtrRecordSet from './data-dns-ptr-record-set';
export * as dataDnsSrvRecordSet from './data-dns-srv-record-set';
export * as dataDnsTxtRecordSet from './data-dns-txt-record-set';
export * as provider from './provider';
